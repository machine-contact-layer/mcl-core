# AP-BOOTSTRAP-1

**Status:** **Candidate.** Normatively complete and implementable from this
document alone. Not Stable: see §11, which records the remaining independent
implementation and public-review boundary rather than more private campaigns.

**Layer:** MCL-AP, transport 1
**Profile identifier:** not yet assigned. See §10.
**Supersedes:** nothing. Experimental profile 192 is a different profile, is not
mutated by this document, and remains Experimental Use forever.

---

## 1. What this profile is for

`AP-BOOTSTRAP-1` carries a raw MCL Wire Tier-0 object between two machines that
have **no prior arrangement of any kind** — no address, no port, no MAC, no
`endpoint_token`, no shared secret, no pairing step, no out-of-band channel.

That is the only thing it is for, and the scope is deliberately narrow. Every
other MCL bearer presupposes that an offer already reached the peer somehow: IP
defers discovery and assigns no port, and a BLE peer is found by an
advertisement a conformant implementation may omit. Acoustic is the one bearer
that needs nothing arranged in advance, which is why the guaranteed
interoperability floor rests on it.

**It is not a general acoustic link.** It carries one small object per
transmission, has no fragmentation, no reliability, no ordering and no flow
control. `AP-LINK-1`, if it is ever written, is a different profile.

## 2. What it is not, stated before the parameters

**No confidentiality, no integrity, no authentication, no replay protection.**
The CRC-16 in §5 detects accidental corruption and nothing else; anyone in
acoustic range can read every byte, and anyone can emit bytes that this profile
will accept.

**It has no credential-bearing and no opaque-payload facility.** There is no
field in which a key, a signature, a token or an authentication exchange can be
placed. Conforming senders **MUST NOT** encode sensitive identity, credential,
key or authentication material into any field of this profile, directly or by
encoding it into a value whose stated purpose is something else
(`ARCHITECTURE_CHARTER.md` §2.11).

This is a property of the format plus a requirement on senders. **It is not an
information-flow guarantee**, and the format cannot enforce one: a sender that
puts a secret into `source_ref` produces bytes this profile will happily
transmit. The absence of a facility removes the obvious way to do it; it does
not make it impossible.

**Authentication belongs after migration.** The intended shape is: meet here,
credential-free and in public; migrate to a richer bearer; authenticate there.
Nothing in MCL forces a signature through air, and `MCL_AP_MODEM_MAX_PAYLOAD_BYTES`
is 64, so a bare Ed25519 signature would not fit if one tried.

## 3. Physical layer

All values are normative. A receiver implementing this profile MUST use them;
they are not defaults.

| Parameter | Value |
|---|---|
| Sample rate | 48000 Hz |
| Symbol rate | 300 baud, exactly 160 samples per symbol |
| Modulation | Binary FSK, continuous phase across every symbol boundary |
| Tone for bit 0 | 3000 Hz |
| Tone for bit 1 | 6000 Hz |
| Bit order | MSB first within each byte |
| Sample format | Signed 16-bit PCM, monaural |

**Phase continuity is normative, not stylistic.** A phase discontinuity at each
bit edge spreads energy across the band, and the receiver's detection windows in
§6 sit exactly on those edges.

### 3.1 Frame envelope

Emitted in this order, with no gaps:

| Section | Duration | Content |
|---|---|---|
| Leading silence | 0.1 s | zero samples |
| Preamble | 0.2 s | linear-FM chirp, 2000 Hz → 6000 Hz |
| Training | 16 symbols | the byte `0x55` twice, alternating 0 and 1 |
| PHY header | 3 bytes | §5 |
| Payload | 1–64 bytes | §4 |
| Trailing silence | 0.5 s | zero samples |

The chirp sweeps linearly in frequency. Its phase MUST be accumulated in a
representation of at least double precision: the quadratic term reaches
2π·6000·0.2 radians, and a single-precision mantissa loses the fractional part
of an angle that size before the chirp ends, producing a reference that stops
matching the transmitted waveform at its own tail — exactly where a correlation
peak is decided.

The chirp's amplitude is scaled so its mean energy per sample is 0.40 relative
to full scale. Receiver correlation is normalised and therefore scale-invariant,
so this fixes the preamble's level **relative to the FSK section** and nothing
else.

**Trailing silence MAY be reduced to 0.1 s** by a transmitter whose buffer
cannot hold more. It is padding, not signal: the receiver locates the payload
from the preamble and needs *its own* capture to extend past the last symbol,
not the transmitter's silence. A receiver MUST NOT depend on trailing silence
being present.

**Emitted amplitude is not specified and is not part of conformance.** Two
implementations at different volumes are both conforming.

## 4. Payload

The payload is **one raw MCL Wire Tier-0 object**, encoded at
`MCL_WIRE_STABLE_MAJOR`, with no Link frame around it.

Carrying a bare Tier-0 object rather than a Link frame is deliberate: the Link
frame adds 8 bytes of header plus optional fields, and §9 shows that length is
the dominant term in acoustic recovery. A 24-byte Link frame carrying a 10-byte
`PRESENCE` was measured at 3/10 where the bare object reached 9/10.

Payload length is 1 to 64 bytes. The three objects this profile exists to carry
are:

| Object | Bytes at major 1 |
|---|---:|
| `PRESENCE` | 10 |
| `TRANSPORT_ACCEPT` | 16 |
| `TRANSPORT_OFFER` | 17 |

A receiver MUST NOT assume the payload is one of these three. It MUST decode it
as a Tier-0 object and refuse anything that does not decode.

## 5. PHY header

Three bytes, immediately after the training symbols:

| Offset | Size | Field |
|---|---|---|
| 0 | 1 | payload length in bytes, 1–64 |
| 1 | 2 | CRC-16/CCITT-FALSE over the payload, big-endian |

CRC-16/CCITT-FALSE: polynomial `0x1021`, initial value `0xFFFF`, no reflection
of input or output, no final XOR.

The CRC covers **the payload only**, not the length byte. A receiver MUST reject
a frame whose declared length is 0 or greater than 64 before computing anything
over it.

## 6. Receiver

### 6.1 Acquisition

Locate the preamble by normalised cross-correlation against a locally generated
reference chirp. A frame is acquired when the normalised correlation magnitude
is **at least 0.40**.

Normalisation is required, not optional: an un-normalised correlation peaks on
loud noise.

### 6.2 Initial timing estimate

From the 16 training symbols, estimate the symbol phase, the symbol rate, and
the decision bias — the offset that separates the two tones' log energy ratio.

**The decision bias is not zero and MUST be estimated.** An acoustic path does
not present two frequencies equally; Experiment 002 measured one tone 19–21 dB
down inside a notch. 97% of bit errors in the retained corpus ran one direction,
which is what an unestimated bias looks like.

### 6.3 Symbol decision

For each symbol, compute the energy at 3000 Hz and at 6000 Hz over that symbol's
160-sample window — a Goertzel evaluation is sufficient and is what the
reference implementation uses. The bit is 1 when `log(E₁/E₀) − bias > 0`.

### 6.4 Whole-frame rate refinement — REQUIRED

**If the first decode attempt fails, a conforming receiver MUST retry with a
refined symbol rate before reporting failure.**

This is normative because it is the difference between a working rendezvous and
a broken one, and §9 measures it.

The refinement:

1. For each candidate rate from `nominal − 0.6` to `nominal + 0.6` samples per
   symbol in steps of `0.01`, where `nominal` is 160.0:
2. Recompute the payload start as `phase + 16 × candidate`. The phase MUST be
   recomputed per candidate: the training symbols precede the payload, so
   changing the rate moves where the payload begins, and holding the old start
   would measure a different frame rather than a better rate.
3. Score the candidate by the **mean decision margin** `mean |log(E₁/E₀) − bias|`
   over the frame.
4. Decode at the highest-scoring rate.

The score uses **only the signal**. It never uses the expected payload, so it is
something a receiver can actually run.

**Why it works.** The initial estimate fits the rate to 16 symbols — 2560
samples. That is too short a baseline: Experiment 010b showed the search already
covered the true rate and still returned a 0.4–0.45 sample error, so the right
answer was inside the grid and was not being chosen. It was a scoring problem,
not a resolution problem, and the fix is more evidence rather than a finer grid:
~160 symbols instead of 16.

**Two terms, only one of which is removable.** After refinement the estimated
rate settles 0.045–0.058 away from nominal rather than at zero, because the
transmitter's and receiver's oscillators are independent and the true received
rate is 160.0 × a clock ratio. Refinement removes estimation error; it cannot
remove genuine clock offset. A frame stops decoding at roughly **0.38 of a
symbol** of accumulated drift, giving a usable length of about `60 / |rate error|`
bits — which is why this profile's objects are small and why it has no
fragmentation.

### 6.5 No forward error correction

This profile specifies **no FEC and no interleaving**, and that is a measured
decision rather than an omission.

Experiment 010 measured the error structure before any coding scheme was
considered: errors are **isolated** (58 of 67 error runs are single bits),
**asymmetric** (77–100% one direction), **low-margin**, and **concentrated in
the frame tail**. That is a timing signature, not independent bit noise.
Interleaving addresses bursts that do not occur here, and a block code sized for
the observed loss would spend airtime — the scarcest resource on this bearer —
carrying a problem that §6.4 removes.

## 7. Transmission behaviour, retries and contention

**Contention is protocol, not modulation.** Ten machines that answer one
`PRESENCE` simultaneously defeat a perfect modem: the replies overlap, all are
lost, and no amount of error correction helps.

### 7.1 Airtime, which sets every other number here

At 300 baud the objects in §4 occupy the medium for:

| Object | Bytes | Airtime |
|---|---:|---:|
| `PRESENCE` | 10 | 600.0 ms |
| `TRANSPORT_ACCEPT` | 16 | 760.0 ms |
| `TRANSPORT_OFFER` | 17 | **786.7 ms** |

(Preamble plus training plus `(3 + payload) × 8` symbols at 160 samples each.)

**A contention window shorter than that cannot separate two transmissions.** An
earlier revision of this section specified a 400 ms reply window, and two
responders placed anywhere inside it overlap with *certainty* — not with some
probability a better random source would reduce. Randomising harder does not
repair an interval that is too short by construction.

### 7.2 The rule

| Parameter | Value | Meaning |
|---|---|---|
| Announce interval | 1500 ms | between successive `PRESENCE` emissions |
| Maximum announcements | 10 | before giving up and reporting nothing heard |
| Backoff slots | 16 | candidate slots in a contention round |
| Backoff slot width | 250 ms | one slot |
| Response timeout | 6000 ms | before an unanswered offer is retried |
| Solicitation timeout | 6000 ms | before an unanswered `PRESENCE` round is abandoned |
| Offer retries | 2 | per bearer, before moving to the next |

**These values are the profile's, not the integrator's.** An implementation
claiming `MCL Stranger-Contact 1` on this medium **MUST** use them. Nothing on
the wire carries a slot count or a timeout, so two builders who chose
differently each behave correctly by their own lights and contend by neither's
— and neither of them can detect it. The reference implementation refuses a
configuration that deviates rather than accepting one, because a configuration
error at the first builder is cheaper than an intermittent interoperability
failure between two shipped products.

**The response timeout is DERIVED, and the derivation is the point.** It was
3000 ms, which is not merely tight but *impossible*: the legal maximum backoff
alone is 15 × 250 = 3750 ms, so a peer behaving perfectly could be declared
silent before it was permitted to answer. Replacing one guessed number with
another would leave the same defect, so it comes from this profile's own
figures:

| Term | Value |
|---|---:|
| maximum contention delay, (16 − 1) × 250 ms | 3750 ms |
| one deferral, a maximum frame's airtime | 787 ms |
| the response itself, a maximum frame's airtime | 787 ms |
| scheduling allowance | 500 ms |
| **sum** | **5824 ms** |

Frozen at the next round number above the sum. If the waveform changes this is
**recomputed**, not adjusted.

The solicitation timeout is numerically equal today and is a **separate
parameter**, because it bounds a different wait (§8) and a future waveform
change need not move both. Sharing one number is how a response timeout came to
be shorter than the backoff it was supposed to contain.

A machine that intends to transmit into the shared medium **MUST**:

1. Draw a slot index uniformly at random from the slot count, and wait that
   many slot widths.
2. At slot expiry, **sense the medium**. If an MCL preamble or transmission is
   detected, **defer**: draw a fresh slot and repeat.
3. Otherwise transmit.

**Deferral is what makes this work, not the delay.** The slot width need only
exceed the acquisition time of a transmission already under way — the preamble
is 200 ms — so a machine drawing a later slot can *see* an earlier one and
yield. That is why 250 ms suffices where 400 ms did not: 400 ms was being asked
to exceed a whole frame, and 250 ms is only being asked to exceed a preamble.

This applies to `PRESENCE` as well as to replies. Machines powered on together
announce together, and a fixed interval keeps them phase-locked so they collide
on every subsequent round; the announce interval is therefore **followed by a
fresh backoff**, not used bare. Bluetooth LE perturbs advertising timing for
this reason, and EPC Gen2 has responders choose among slots rather than delay
within a window; the shared conclusion is that randomness must affect the
transmission *opportunity*, not merely add an offset smaller than the packet.

**Randomness is REQUIRED, not preferred.** An implementation without a random
source MUST NOT claim `MCL Stranger-Contact 1` on a shared medium. Deriving the
slot from `source_ref` was previously permitted and is now forbidden: wire.h
assigns `source_ref` no uniqueness property, so two builders may legally choose
the same value and then collide on every round forever. A deterministic
function of a non-unique value provides no multi-builder guarantee.

**Medium sensing is REQUIRED** for the same claim. Step 2 is not optional, and
an implementation that cannot sense cannot perform it.

**Retry the same bearer before concluding anything about the peer.** On this
bearer a lost offer and an unsupported bearer are indistinguishable, and §9
measures the 17-byte `TRANSPORT_OFFER` failing often enough that a single
unanswered offer is no evidence at all about what the peer supports.

## 8. Finding a common bearer

A peer that hears a `PRESENCE` learns that a machine is present and **nothing
about what it speaks.**

This is a property of major-1 `PRESENCE`, not a limitation of this profile:
`machine_class` was removed from the major-1 body, and `capability_tag` is
normatively a sender-controlled opaque revision token that a receiver is
**forbidden** to compare across peers.

A common bearer is therefore found by **ordered trial**, not by intersection.
Each peer offers the bearers its deployment mandates, in the order the
deployment profile fixes, and `TRANSPORT_ACCEPT` or a timeout answers. Two
independent builders converge because they were handed the same ordered list,
not because they exchanged one.

### 8.1 One machine owns each round — REQUIRED

Ordered trial says *what* is offered. It does not say *who* offers, and on an
unaddressed broadcast medium that omission does not stay abstract.

`TRANSPORT_OFFER` carries no destination. Any machine that hears one and
mandates the bearer may answer it. If every machine may also announce, respond,
offer and accept at the same instant, then with two machines the roles happen
to be complementary and nothing shows — and with three the exchange does not
converge. Measured in simulation over 600 s, three machines on one medium:

```
36 BEARER_AGREED, 0 CANDIDATE_VALIDATED, 0 CONTACT_MIGRATED
```

Every agreement landed on an acceptor, no machine ever became a controller, and
nothing drove a handoff. The cycle — A holding B as its peer, B holding C, C
holding A — is stable and never breaks on its own.

So each round has exactly one owner:

| Object | Role |
|---|---|
| `PRESENCE` | solicitation |
| `TRANSPORT_OFFER` | a contender's response |
| `TRANSPORT_ACCEPT` | selection of one contender, by `migration_ref` |

An implementation claiming `MCL Stranger-Contact 1` on this medium **MUST**:

1. On successfully emitting a `PRESENCE`, become the **solicitor** for that
   round and arm the solicitation timeout. A solicitor **MUST NOT** become a
   responder to another machine's `PRESENCE` during that round.
2. On receiving a `PRESENCE` **before** transmitting its own, cancel the
   pending announcement and become a **responder** for that round. A responder
   **MUST NOT** consume another machine's `TRANSPORT_OFFER`: it is answering a
   round it does not own.
3. As solicitor, accept the **first** valid `TRANSPORT_OFFER` of a mandated
   bearer, bind that contender, and ignore later contenders for the round.
4. As responder, match `TRANSPORT_ACCEPT` on the outstanding
   `migration_ref`, `transport_id` and `profile_id`. On the first match, bind
   `peer_ref` from the acceptance, become the migration controller, and
   proceed. A contender whose reference is not the one echoed **MUST NOT**
   adopt the transaction; it **SHOULD** return to contention rather than hold
   the medium for its remaining offer retries.

Two `PRESENCE` frames in one slot collide, nobody hears either, both solicitors
time out and both re-draw. This is why the **first** announcement is backed off
like every other transmission: it is otherwise the one synchronised instant in
the whole lifecycle, and machines powered on from a single switch meet exactly
there.

No wire field was added for any of this. `TRANSPORT_ACCEPT` already echoes
`migration_ref`, and that echo is the selection.

**The hidden terminal is not solved by any of this, and is not claimed to be.**
Every rule above assumes a contender can hear the acceptance that selects
somebody else. Two responders out of earshot of each other, both in range of
the solicitor, cannot: each senses an idle medium, both transmit, and their
offers collide at the solicitor while neither transmitter observes anything
wrong. Acoustically this is ordinary — a wall, a corner, a directional speaker
— and carrier sensing cannot detect it by construction.

What the rules give is that the failure is **survivable rather than
structural**: the colliding offers are lost, the solicitation times out, both
contenders re-draw a slot, and a later round succeeds. Rule 4's stand-down is
an optimisation and is written as **SHOULD** for exactly this reason: a
contender that never hears the acceptance still converges, through its offer
retries, more slowly.

There is no RTS/CTS here and none is proposed. A handshake to reserve the
medium costs two more frames of 600-790 ms each on a bearer whose entire
purpose is to carry one object to a stranger, and it would still not help the
case where the two contenders cannot hear each other's reservations either.
Deployments where hidden terminals are the normal case, rather than the
occasional one, need a bearer with a coordinator; that is a deployment-profile
decision and not something this profile can fix.

### 8.2 `migration_ref` MUST be random on this medium

Because `migration_ref` now selects one contender out of several, a value
derived from `source_ref` is not sufficient here.

`source_ref` is normatively a correlation reference with **no uniqueness
property**. Two builders may legally hold the same one, so a reference computed
as a function of `source_ref` and a local counter is identical on both of their
first transactions — and one `TRANSPORT_ACCEPT` then tells both of them they
were selected.

An implementation claiming `MCL Stranger-Contact 1` on this medium therefore
**MUST** draw a fresh, non-zero, random 32-bit `migration_ref` per transaction.
A retransmission **MUST** reuse the same value; a new transaction **MUST** draw
another. Randomness is already required by §7.2, so this adds no dependency.

A solicitor that observes two `TRANSPORT_OFFER`s carrying one `migration_ref`
from different sources **MUST** abandon the round rather than select either. It
cannot name the transaction it would be accepting, and selecting anyway leaves
two machines believing they were chosen.

This is an interaction constraint of *this profile*. It does not make
`migration_ref` an identity or a security property anywhere in MCL.

### 8.3 Glare

Simultaneous offers cannot arise under §8.1: only a responder emits an offer
and only the solicitor consumes one, so there is no state in which two machines
hold offers outstanding to each other.

Where a caller drives `mcl_contact_t` directly, outside this profile's round
structure, the existing rule in
[link-contact-ownership-v0.1.md](reference/mcl-link/spec/link-contact-ownership-v0.1.md) still applies: the larger
`(source_ref, migration_ref)` key wins the controller role, and an exact tie
aborts both transactions.

## 9. Evidence

Experiment 011, 2026-09-06. DFR1154 speaker → laptop microphone, independent
clocks, 15 trials per cell, one session and one level.

| Object | Bytes | Acquired | Without §6.4 | With §6.4 |
|---|---:|---:|---:|---:|
| `PRESENCE` | 10 | 15/15 | 9/15 | **15/15** |
| `TRANSPORT_ACCEPT` | 16 | 15/15 | 8/15 | **15/15** |
| `TRANSPORT_OFFER` | 17 | 15/15 | 4/15 | **14/15** |

21/45 → 44/45. Both columns are computed from the **same captures**, so the
difference is the receiver and not a better room.

Offline regression on the previously retained corpus, no new transmission:
10-byte cell 9/10 → 10/10, 24-byte cell 3/10 → 5/10.

## 10. Registry

**No profile identifier is assigned by this document.**

Assignment requires the [REGISTRY_POLICY.md](reference/mcl-core/governance/REGISTRY_POLICY.md) §2
requirements and, for a Standards Action value, the interoperability evidence
that §11 says does not yet exist. Assigning a number now and justifying it later
is the failure the registry policy was written to prevent.

Experimental Use profile 192 is **not** this profile and is not relabelled.

## 11. Why this is Candidate and not Stable

One thing is missing, and it is not more text.

**Current release status (2026-09-12):** the retained DFR1154/Android/Windows
campaign closed the private v1 builder-interoperability floor, including the
bounded three-party shared-air contention criterion. The historical evidence
below remains unchanged. This profile is still Candidate because independent
external implementation/review and a Stable profile identifier remain open
after publication; no further private campaign is required for v1.

**Every measurement of this waveform comes from one transmitter class.** The
3000/6000 Hz pair was chosen on the DFR1154's speaker and confirmed on the same
speaker. The `mcl-ap` band registry already records that this pair must not be
standardised on the strength of one campaign, and Experiment 011 is a second
campaign on the same transmitter rather than a second transmitter.

There is direct evidence that the choice does not travel. A loopback through
this host's speaker recovered 1 of 3 at 10 bytes where the board rig recovers
9 of 15, and scored the same way as the candidates, the incumbent pair is
**10.97 dB** behind the best pair on that path (experiment 012).

**One earlier explanation of that result is withdrawn.** This document
previously said the host speaker "has a measured notch around 3 kHz", one of
the two tones. It does not: in experiment 012's dataset 3000 Hz reads
**65.92 dB SNR**, one of that path's stronger bins. The notch is at **3600 Hz**,
about one bin wide, between neighbours at 3300 Hz (58.71 dB) and 3900 Hz
(42.68 dB) — it touches neither tone. The claim came from a scoring defect that
let a single bin decide a pair; the retraction and the recomputation are in
`experiments/012-multi-transmitter-band/README.md`. The conclusion that the
pair does not travel survives, on the corrected numbers, but it is no longer
attributed to a notch under a tone.

**That host path is also no longer qualifying evidence.** Its speaker is
physically damaged, with rising mechanical noise. Its measurements stay
published and unedited as negative and context evidence — they are what first
showed the choice does not travel — but a damaged transducer must not
contribute to selecting the waveform.

Promotion to Stable requires:

1. **Outstanding.** The band swept on **at least two materially different,
   healthy transmitter classes, including at least one class not used to select
   the original waveform**, each measured through its **actual end-to-end audio
   path** — the amplifier, any OEM signal processing and the transducer that a
   deployment would really use, not an idealised source. The pair must be
   selected from that evidence rather than inherited, by **worst case across the
   matrix** rather than by average. This is the load-bearing gap.

   This criterion replaces an earlier one requiring "two transmitter classes
   that are not the DFR1154". That test counted classes; this one asks whether
   the choice travels. It was changed because one of the three available paths
   is a physically damaged speaker, and a broken transducer does not become
   evidence by making the count three. **It is not a relaxation:** a healthy
   class not used to choose the waveform is still mandatory, and each class must
   now be exercised through its real audio path in both directions where the
   class can also receive.

   The two intended classes are the DFR1154 speaker/amplifier path and an
   Android handset media path. Where a handset's response changes with drive
   level, that is an **operating condition of a real transmitter chain**, not a
   disqualification — PCM through the platform media stack, OEM processing,
   amplifier and speaker is the transmitter a builder actually meets. Record the
   operating points and require the selected pair to survive all of them.
2. **Partly done.** A receiver written from this document alone now exists —
   `conformance/independent/ap_bootstrap_rx.py`, sharing no code with `mcl-ap`,
   in a language that cannot accidentally link it — and it agrees with the
   reference on all nine vectors in both directions
   (`conformance/check-vectors.sh`).

   That demonstrates this document is **self-sufficient**: no parameter a
   receiver needs lives only in the reference implementation. It does **not**
   demonstrate the document is unambiguous to someone who has never seen that
   implementation, because the same author wrote both.

   **The remaining half is not a private task.** This project's evidence rule
   makes internal clean-room independence a matter of **code and provenance**
   independence, which is what the Python receiver establishes. A genuinely
   unrelated reader is **public review**, which the charter requires for Stable
   in any case and which cannot happen while the repositories are unpublished.
   This item is therefore closed as far as private work can close it, and the
   rest is sequenced after publication — it is not a reason to withhold the
   Candidate profile, and no one is waiting privately for a stranger to
   implement it.
3. **Done.** `conformance/vectors/`, three positive and six negative, each
   negative refusing for a different reason. Their limit is stated in the
   manifest and repeated here because it matters: they are noise-free, so a
   receiver that omitted §6.4 entirely would pass them. Timing recovery is what
   fails in a room, and these vectors have perfect timing.
4. **Outstanding.** A **three-or-more machine contention campaign**. §7's rule
   is now derived from airtime rather than guessed, and is exercised against a
   simulator that models overlap ([test_rendezvous.c](reference/mcl-sdk/tests/test_rendezvous.c)), but
   simulated air is not air.
5. **Outstanding.** A profile identifier assigned under §10.

**One of the five is closed, one is half closed, and three are outstanding.**
An earlier revision of this section said "two of five are closed" and then
"the two that remain outstanding", which does not add up to five and was
generous to this profile in both halves of the same sentence.

The three that remain need something no amount of text supplies: a second class
of transmitter, a third machine, and an interoperability record that justifies
an assigned number. Item 2's remaining half needs a reader who has never seen
the reference implementation.

Until then a deployment may implement `AP-BOOTSTRAP-1` and MUST NOT describe it
as frozen.
