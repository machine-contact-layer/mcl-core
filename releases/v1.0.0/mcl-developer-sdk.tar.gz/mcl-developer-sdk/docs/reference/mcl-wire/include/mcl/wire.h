#ifndef MCL_WIRE_H
#define MCL_WIRE_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define MCL_WIRE_EXPERIMENTAL_MAJOR 0u

/*
 * The first Stable major.
 *
 * CUT for v1.0. The codec encodes and decodes it, and the immutable major-1
 * vector family is frozen against it.
 *
 * Cutting was gated on the Stable meanings closing
 * (mcl-core/governance/V1_SCOPE.md section 5.8), because accepting frames under
 * a major whose bodies are not frozen would itself have been the cutting. The
 * RULE that governs which objects this major may carry was written and tested
 * BEFORE the first major-1 vector was generated -- see
 * mcl_wire_kind_allowed_at_major and mcl-wire/tests/test_major_rule.c -- so
 * that no vector was frozen under an ambiguous rule.
 *
 * What this major carries is not "everything implemented": only PRESENCE,
 * TRANSPORT_OFFER and TRANSPORT_ACCEPT. A Candidate object offered here is
 * refused, not decoded.
 */
#define MCL_WIRE_STABLE_MAJOR 1u

#define MCL_WIRE_COMMON_HEADER_SIZE 2u
#define MCL_WIRE_TIER0_MAX_SIZE 17u

typedef int32_t mcl_wire_status_t;
enum {
    MCL_WIRE_OK = 0,
    MCL_WIRE_ERR_INVALID_ARGUMENT = 1,
    MCL_WIRE_ERR_BUFFER_TOO_SMALL = 2,
    MCL_WIRE_ERR_RANGE = 3,
    MCL_WIRE_ERR_TRUNCATED = 4,
    MCL_WIRE_ERR_UNSUPPORTED_SEMANTIC = 5,
    MCL_WIRE_ERR_NONCANONICAL = 6
};

typedef uint8_t mcl_wire_kind_t;
enum {
    MCL_WIRE_KIND_PRESENCE = 0u,
    MCL_WIRE_KIND_HAZARD = 1u,
    MCL_WIRE_KIND_REQUEST = 2u,
    MCL_WIRE_KIND_AUTHORITY_CLAIM = 3u,
    MCL_WIRE_KIND_DEGRADED_STATE = 4u,
    MCL_WIRE_KIND_TRANSPORT_OFFER = 5u,
    MCL_WIRE_KIND_TRANSPORT_ACCEPT = 6u
};

/*
 * A STABLE MAJOR CARRIES ONLY STABLE SEMANTICS.
 *
 * V1_SCOPE.md section 4.7. Wire major 1 carries PRESENCE, TRANSPORT_OFFER and
 * TRANSPORT_ACCEPT and nothing else. HAZARD, REQUEST, AUTHORITY_CLAIM and
 * DEGRADED_STATE are Candidate -- their layouts exist and their vectors pass,
 * but their MEANINGS may still change, and a Candidate body carried inside a
 * frozen major would let two decoders both correctly implementing "major 1"
 * read one category/opcode under two different layouts. That is the exact
 * failure a major version exists to prevent.
 *
 * Candidate objects therefore stay on the experimental major until they are
 * separately promoted. The consequence, stated because implementers will meet
 * it: a node doing first contact and also reporting hazards emits objects of
 * two different majors. That is permitted -- the major is a per-object header
 * field, not a per-link property -- but a peer must not infer support for one
 * major from having seen the other.
 *
 * Returns 1 if `kind` may be carried at `major`, 0 otherwise. An unassigned
 * major answers 0: unknown is refused, never guessed.
 */
int mcl_wire_kind_allowed_at_major(uint8_t major, mcl_wire_kind_t kind);

typedef struct {
    uint8_t major_version;
    uint8_t category;
    uint8_t opcode;
    uint8_t priority;
    uint8_t extension_present;
} mcl_wire_header_t;

/*
 * capability_tag is a 24-bit SENDER-CONTROLLED OPAQUE REVISION TOKEN.
 *
 * It was called capability_digest, and that name was a lie. "Digest" asserts
 * that equal values imply equal capabilities, and nothing provided that
 * property: there was no canonical input, no algorithm, and no collision
 * semantics. Nothing computed it. Charter 2.11 forbids naming a mechanism for a
 * property it lacks, and an implementer who trusted the old name would have
 * compared two senders' values and concluded something false.
 *
 * Defining a real digest was the alternative and was rejected: it needs a
 * canonical capability serialisation, an algorithm with its own versioning, and
 * collision semantics for a 24-bit space whose birthday bound is around 4096
 * distinct capability sets. That is a great deal of machinery for what PRESENCE
 * actually needs, which is "have your capabilities changed since I last asked".
 *
 * NORMATIVE CONTRACT
 *
 *   The sender MUST change capability_tag when the set or meaning of the
 *   capabilities it advertises for the current contact changes.
 *
 *   A receiver MUST scope the tag to the advertising source/contact. It MUST
 *   NOT compare tags from different peers as capability identities.
 *
 *   The tag provides no authenticity, no integrity, no uniqueness and no
 *   cryptographic collision resistance.
 *
 *   A receiver MAY use equality only as a cache or renegotiation hint.
 *
 * No randomness and no hashing is required. Incrementing a counter conforms.
 * A collision between two senders is harmless by construction, because
 * comparing across senders is forbidden; a collision within one sender costs
 * one unnecessary capability exchange.
 *
 * `capability_revision` was considered and rejected: it implies monotonicity
 * this contract does not require.
 */
typedef struct {
    uint8_t machine_class;
    uint32_t capability_tag;
    uint8_t ttl;
} mcl_wire_presence_t;

typedef struct {
    uint8_t hazard_class;
    uint8_t severity;
    uint8_t confidence;
    int16_t x;
    int16_t y;
    int16_t z;
    uint16_t radius;
    uint8_t ttl;
} mcl_wire_hazard_t;

typedef struct {
    uint8_t request_class;
    uint32_t target_ref;
    int16_t x;
    int16_t y;
    uint16_t radius;
    uint8_t ttl;
} mcl_wire_request_t;

typedef struct {
    uint8_t authority_class;
    uint16_t jurisdiction;
    uint32_t credential_ref;
    uint8_t validity;
} mcl_wire_authority_claim_t;

typedef struct {
    uint8_t affected_capability;
    uint8_t health;
    uint8_t severity;
    uint8_t ttl;
} mcl_wire_degraded_state_t;

/*
 * migration_ref correlates one transport-change transaction, and nothing else.
 *
 * Without it a delayed acceptance from an abandoned offer is indistinguishable
 * from the acceptance of the current one, because transport_id and profile_id
 * are usually identical across a retry. Mature request/response protocols carry
 * a dedicated correlator for exactly this reason: CoAP's Token, which the
 * responder echoes, and MCTP's message tag, which is kept separate from
 * endpoint addressing rather than overloaded onto it.
 *
 * It is NOT identity, NOT authorization, NOT a session, and NOT a secret. Zero
 * is reserved so an uninitialised field never names a live transaction.
 */
typedef struct {
    uint32_t migration_ref;
    uint8_t transport_id;
    uint8_t profile_id;
    uint32_t endpoint_token;
    uint8_t validity;
} mcl_wire_transport_offer_t;

/*
 * TRANSPORT_ACCEPT is the other half of a transport change. Without it the
 * offering peer never learns which transport was selected, so two independent
 * implementations cannot complete a migration -- which is exactly the test for
 * whether something belongs in the specification.
 *
 * session_ref carries the accepting peer's chosen correlation reference for the
 * continued contact. It is a CORRELATION REFERENCE AND NOT A SECRET: it travels
 * in the clear over an observable medium, so anyone in range can read it and
 * anyone can quote it back. It lets an honest peer recognise a continuing
 * contact; it establishes nothing whatever about who the peer is.
 */
typedef struct {
    uint32_t migration_ref;
    uint8_t transport_id;
    uint8_t profile_id;
    uint32_t session_ref;
} mcl_wire_transport_accept_t;

typedef struct {
    mcl_wire_kind_t kind;
    uint8_t priority;
    uint32_t source_ref;
    union {
        mcl_wire_presence_t presence;
        mcl_wire_hazard_t hazard;
        mcl_wire_request_t request;
        mcl_wire_authority_claim_t authority_claim;
        mcl_wire_degraded_state_t degraded_state;
        mcl_wire_transport_offer_t transport_offer;
        mcl_wire_transport_accept_t transport_accept;
    } body;
} mcl_wire_tier0_t;

/* ============================================================
 * DURATION CODES
 *
 * `ttl` and `validity` are both 8-bit duration fields, and both had no unit and
 * no scale: eight bits meaning "some duration". A receiver was forbidden to
 * infer seconds, which made them undecidable rather than merely imprecise.
 *
 * ONE ENCODING, USED BY BOTH. Two duration fields with different scales in one
 * protocol is a defect waiting to be written.
 *
 * Layout: a 4-bit exponent in the high nibble, a 4-bit mantissa in the low.
 *
 *     e == 0   seconds = m                      0..15, in 1 s steps
 *     e >= 1   seconds = (16 + m) << (e - 1)    16..507904
 *
 * The implied leading one above e == 0 is what makes the mapping INJECTIVE:
 * every representable duration has exactly one code, so a decoder never has two
 * answers and an encoder never has two choices. A plain `m << e` would encode
 * 64 seconds five different ways, and canonical form is not optional here.
 *
 * The range runs to 507904 s, a little under six days, and quantization costs
 * at most 5.88% of a requested duration above one minute -- measured across the
 * whole range, not estimated. Both ends matter: a field that cannot express
 * "for the rest of the shift" gets worked around, and a work-around is a second
 * scale.
 *
 * The bands do not touch. Band `e` covers 16<<(e-1) .. 31<<(e-1), so between
 * one band's top and the next band's bottom sits a gap of one step; 253952 and
 * 262144 are both representable and nothing between them is. A duration landing
 * in a gap rounds down to the band below.
 *
 * THERE IS NO CODE FOR "FOREVER", deliberately. An unbounded lifetime is the
 * opposite of what a TTL is for, and a sentinel meaning it would be reached for
 * by every sender that did not want to think about expiry.
 *
 * Zero is a real value meaning zero seconds: decode the object, then stop
 * treating it as current. It does not mean "unset".
 * ============================================================ */

#define MCL_WIRE_DURATION_MAX_SECONDS 507904u

/* Seconds named by a duration code. All 256 codes are valid, so this is total
 * and needs no status. */
uint32_t mcl_wire_duration_seconds(uint8_t code);

/*
 * The code for a duration, ROUNDED DOWN to the nearest representable value.
 *
 * Down, never up and never nearest. These fields bound how long a receiver may
 * keep treating something as current, so rounding up would extend the life of
 * stale information by up to one quantum every time it was re-encoded. Rounding
 * down can only shorten a bound, which is the safe direction.
 *
 * A duration above MCL_WIRE_DURATION_MAX_SECONDS is REFUSED with
 * MCL_WIRE_ERR_RANGE rather than clamped. Silently turning thirty days into six
 * is the kind of rounding that gets discovered in the field.
 */
mcl_wire_status_t mcl_wire_duration_encode(uint32_t seconds, uint8_t *code);

mcl_wire_status_t mcl_wire_header_encode(const mcl_wire_header_t *header, uint8_t out[MCL_WIRE_COMMON_HEADER_SIZE]);
mcl_wire_status_t mcl_wire_header_decode(const uint8_t in[MCL_WIRE_COMMON_HEADER_SIZE], mcl_wire_header_t *header);

size_t mcl_wire_tier0_encoded_size(mcl_wire_kind_t kind);

/*
 * Encoded size of `kind` as carried at `major`. Returns 0 when that major does
 * not carry that kind at all.
 *
 * The two majors do NOT agree about PRESENCE. Major 1 drops machine_class, so
 * a major-1 PRESENCE is 10 bytes where a major-0 PRESENCE is 11. That is the
 * whole reason this function exists: a size derived from the kind alone was
 * correct while only one major existed and silently stops being correct the
 * moment a second one does.
 *
 * Decided from evidence, not preference -- mcl-core/governance/
 * MACHINE_CLASS_AUDIT.md found no consumer of machine_class in any of the eight
 * repositories and a research corpus containing two distinct values. Major 0
 * keeps its layout, its vectors and its evidence unchanged and permanently.
 */
size_t mcl_wire_tier0_encoded_size_at_major(uint8_t major, mcl_wire_kind_t kind);

/*
 * Encode at a specific Wire major.
 *
 * mcl_wire_tier0_encode() is this function at MCL_WIRE_EXPERIMENTAL_MAJOR, kept
 * so that callers written before major 1 was cut continue to compile and to
 * emit exactly the bytes they emitted before. v1.0 promises source
 * compatibility (V1_SCOPE 4.5), and silently changing what an existing call
 * puts on the wire would break it in the worst possible way -- invisibly.
 *
 * Returns MCL_WIRE_ERR_UNSUPPORTED_SEMANTIC when `major` does not carry
 * `object->kind`: a Candidate object at the Stable major, or any unassigned
 * major.
 *
 * The two majors do not agree about PRESENCE. Major 1 omits machine_class, so
 * the same object encodes to 11 bytes at major 0 and 10 at major 1.
 */
mcl_wire_status_t mcl_wire_tier0_encode_at_major(
    uint8_t major,
    const mcl_wire_tier0_t *object,
    uint8_t *out,
    size_t out_capacity,
    size_t *written);

mcl_wire_status_t mcl_wire_tier0_encode(
    const mcl_wire_tier0_t *object,
    uint8_t *out,
    size_t out_capacity,
    size_t *written);

/*
 * Decode a Tier-0 object.
 *
 * Refuses an object whose header sets extension_present, because this decoder
 * cannot read extensions and an extension may be critical -- the sender saying
 * the object must not be acted on without it. Returning the body and
 * discarding the rest would turn "you must understand this" into "you may
 * ignore this". To read extensions, use mcl_wire_tier0_decode_ext in
 * mcl/extension.h.
 */
mcl_wire_status_t mcl_wire_tier0_decode(
    const uint8_t *data,
    size_t data_size,
    mcl_wire_tier0_t *object,
    size_t *consumed);

/*
 * Decode the fixed Tier-0 body ONLY, ignoring extension_present entirely.
 *
 * Shared between mcl_wire_tier0_decode and the extension-aware decoder, which
 * is the reason it is public rather than static: extension handling lives in
 * a separate translation unit so that a build with no use for extensions does
 * not link them.
 *
 * `consumed` reports the fixed body length. Any extension block begins there.
 * A caller using this directly is responsible for the extension_present bit,
 * and gets no protection from a critical extension. Prefer the two functions
 * above.
 */
mcl_wire_status_t mcl_wire_tier0_decode_body(
    const uint8_t *data,
    size_t data_size,
    mcl_wire_tier0_t *object,
    size_t *consumed);

#ifdef __cplusplus
}
#endif

#endif
